setTimeout(function () { window.print(); }, 100);
setTimeout(function () { history.go(-2); }, 500);