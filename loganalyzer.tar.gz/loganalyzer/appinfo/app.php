<?php

namespace OCA\loganalyzer
$app = new Application();

