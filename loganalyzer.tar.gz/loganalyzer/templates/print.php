
<?php
script('loganalyzer', 'print');
style('loganalyzer', 'style');
?>
<center>
<h1>KZGM Cloud Report</h1>
</center>